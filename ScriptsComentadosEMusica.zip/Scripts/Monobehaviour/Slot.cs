using UnityEngine;
using UnityEngine.UI;

//Armazena um texto
public class Slot : MonoBehaviour
{
    public Text qtdTexto;
}
