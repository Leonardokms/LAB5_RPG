using UnityEngine;
public class Consumable : MonoBehaviour
{
	//Recebe um item
    public Item item;
}
