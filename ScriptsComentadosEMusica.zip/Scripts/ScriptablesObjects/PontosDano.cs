using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Pontos Dano")]

public class PontosDano : ScriptableObject
{
    public float valor;         // armazena quanto vale o objeto script
}
