Sem muito segredo
Colocar os scripts dentro da pasta script,
Colocar a pasta Musica dentro da pasta Assets
Colocar os dois prefabs dentro da pasta Prefabs e arrastar cada um pra cena relevante e testar
